
<!-- Bootstrap core JavaScript -->
<script src="{{URL::asset('vendor/jquery/jquery.min.js')}}"></script>
<script src="{{URL::asset('vendor/popper/popper.min.js')}}"></script>
<script src="{{URL::asset('vendor/bootstrap/js/bootstrap.min.js')}}"></script>
<!-- Plugin JavaScript -->
<script src="{{URL::asset('vendor/jquery-easing/jquery.easing.min.js')}}"></script>
<script src="{{URL::asset('vendor/chart.js/Chart.min.js')}}"></script>
<script src="{{URL::asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{URL::asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>
<!-- Custom scripts for this template -->
<script src="{{URL::asset('js/sb-admin.js')}}"></script>
<script src="{{URL::asset('js/bill-script.js')}}"></script>
</body>
</html>
