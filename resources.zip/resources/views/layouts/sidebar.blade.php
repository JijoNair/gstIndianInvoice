<div id="wrapper">
   <!-- Sidebar -->
   <div id="sidebar-wrapper">
      <ul class="sidebar-nav nav-pills nav-stacked" id="menu">
        <li class="active">
           <a href="{{'/index'}}"><span class="fa-stack fa-lg pull-left"><i class="fa fa-server fa-stack-1x "></i></span>Dashboard</a>
        </li>
         <li >
            <a href=""><span class="fa-stack fa-lg pull-left"><i class="fa fa-dashboard fa-stack-1x "></i></span>Shops</a>
            <ul class="nav-pills nav-stacked" style="list-style-type:none;">
               <li><a href="{{'/shops'}}">List Shops</a></li>
               {{-- <li><a href="#">link2</a></li> --}}
            </ul>
         </li>
         <li>
            <a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-flag fa-stack-1x "></i></span>Bills</a>
            <ul class="nav-pills nav-stacked" style="list-style-type:none;">
               <li><a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-flag fa-stack-1x "></i></span>link1</a></li>
               <li><a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-flag fa-stack-1x "></i></span>link2</a></li>
            </ul>
         </li>
         <li>
            <a href="{{'/logout'}}"><span class="fa-stack fa-lg pull-left"><i class="fa fa-server fa-stack-1x "></i></span>Log out</a>
         </li>
      </ul>
   </div>
   <!-- /#sidebar-wrapper -->
   <!-- Page Content -->
