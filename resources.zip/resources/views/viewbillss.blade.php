<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=8">
<title>bcl_461620437.htm</title>
<meta name="generator" content="BCL easyConverter SDK 5.0.08">
<style type="text/css">

body {margin-top: 0px;margin-left: 0px;}

#page_1 {position:relative; overflow: hidden;margin: 26px 0px 185px 47px;padding: 0px;border: none;width: 746px;}
#page_1 #id_1 {border:none;margin: 0px 0px 0px 0px;padding: 0px;border:none;width: 746px;overflow: hidden;}
#page_1 #id_2 {border:none;margin: 12px 0px 0px 205px;padding: 0px;border:none;width: 541px;overflow: hidden;}

#page_1 #p1dimg1 {position:absolute;top:34px;left:0px;z-index:-1;width:626px;height:851px;}
#page_1 #p1dimg1 #p1img1 {width:626px;height:851px;}




.ft0{font: bold 16px 'Helvetica';line-height: 19px;}
.ft1{font: 1px 'Helvetica';line-height: 1px;}
.ft2{font: bold 13px 'Helvetica';line-height: 16px;}
.ft3{font: 11px 'Helvetica';line-height: 14px;}
.ft4{font: bold 12px 'Helvetica';line-height: 15px;}
.ft5{font: 1px 'Helvetica';line-height: 13px;}
.ft6{font: 11px 'Helvetica';line-height: 13px;}
.ft7{font: 1px 'Helvetica';line-height: 12px;}
.ft8{font: 11px 'Helvetica';line-height: 12px;}
.ft9{font: 1px 'Helvetica';line-height: 6px;}
.ft10{font: 1px 'Helvetica';line-height: 5px;}
.ft11{font: 1px 'Helvetica';line-height: 7px;}
.ft12{font: 12px 'Helvetica';line-height: 15px;}
.ft13{font: 13px 'Helvetica';line-height: 16px;}
.ft14{font: 8px 'Helvetica';line-height: 10px;}
.ft15{font: italic 12px 'Helvetica';line-height: 15px;}
.ft16{font: 1px 'Helvetica';line-height: 10px;}
.ft17{font: 1px 'Helvetica';line-height: 9px;}
.ft18{font: italic bold 13px 'Helvetica';line-height: 16px;}
.ft19{font: italic 13px 'Helvetica';line-height: 16px;}
.ft20{font: 1px 'Helvetica';line-height: 3px;}
.ft21{font: 1px 'Helvetica';line-height: 4px;}
.ft22{font: 1px 'Helvetica';line-height: 14px;}
.ft23{font: 12px 'Helvetica';line-height: 14px;}

.p0{text-align: left;padding-left: 268px;margin-top: 0px;margin-bottom: 0px;}
.p1{text-align: left;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p2{text-align: left;padding-left: 3px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p3{text-align: left;padding-left: 2px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p4{text-align: left;padding-left: 67px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p5{text-align: right;padding-right: 14px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p6{text-align: left;padding-left: 10px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p7{text-align: right;padding-right: 25px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p8{text-align: left;padding-left: 5px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p9{text-align: right;padding-right: 31px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p10{text-align: left;padding-left: 31px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p11{text-align: right;padding-right: 6px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p12{text-align: left;padding-left: 6px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p13{text-align: right;padding-right: 5px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p14{text-align: left;padding-left: 15px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p15{text-align: right;padding-right: 7px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p16{text-align: left;padding-left: 131px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p17{text-align: left;padding-left: 23px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p18{text-align: right;padding-right: 15px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p19{text-align: left;padding-left: 189px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p20{text-align: right;padding-right: 10px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p21{text-align: left;padding-left: 32px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p22{text-align: left;padding-left: 62px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p23{text-align: right;padding-right: 39px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p24{text-align: left;padding-left: 20px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p25{text-align: right;padding-right: 29px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p26{text-align: right;padding-right: 17px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p27{text-align: right;padding-right: 26px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p28{text-align: right;padding-right: 4px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p29{text-align: left;padding-left: 213px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p30{text-align: left;padding-left: 12px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p31{text-align: left;padding-left: 27px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p32{text-align: left;margin-top: 0px;margin-bottom: 0px;}

.td0{padding: 0px;margin: 0px;width: 2px;vertical-align: bottom;}
.td1{padding: 0px;margin: 0px;width: 277px;vertical-align: bottom;}
.td2{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 34px;vertical-align: bottom;}
.td3{padding: 0px;margin: 0px;width: 106px;vertical-align: bottom;}
.td4{padding: 0px;margin: 0px;width: 29px;vertical-align: bottom;}
.td5{padding: 0px;margin: 0px;width: 16px;vertical-align: bottom;}
.td6{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 2px;vertical-align: bottom;}
.td7{padding: 0px;margin: 0px;width: 82px;vertical-align: bottom;}
.td8{padding: 0px;margin: 0px;width: 70px;vertical-align: bottom;}
.td9{padding: 0px;margin: 0px;width: 1px;vertical-align: bottom;}
.td10{padding: 0px;margin: 0px;width: 3px;vertical-align: bottom;}
.td11{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 135px;vertical-align: bottom;}
.td12{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 16px;vertical-align: bottom;}
.td13{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 82px;vertical-align: bottom;}
.td14{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 70px;vertical-align: bottom;}
.td15{padding: 0px;margin: 0px;width: 152px;vertical-align: bottom;}
.td16{padding: 0px;margin: 0px;width: 36px;vertical-align: bottom;}
.td17{padding: 0px;margin: 0px;width: 23px;vertical-align: bottom;}
.td18{padding: 0px;margin: 0px;width: 28px;vertical-align: bottom;}
.td19{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 36px;vertical-align: bottom;}
.td20{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 29px;vertical-align: bottom;}
.td21{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 23px;vertical-align: bottom;}
.td22{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 2px;vertical-align: bottom;}
.td23{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 28px;vertical-align: bottom;}
.td24{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 17px;vertical-align: bottom;}
.td25{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 260px;vertical-align: bottom;}
.td26{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 34px;vertical-align: bottom;}
.td27{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 71px;vertical-align: bottom;}
.td28{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 1px;vertical-align: bottom;}
.td29{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 3px;vertical-align: bottom;}
.td30{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 16px;vertical-align: bottom;}
.td31{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 259px;vertical-align: bottom;}
.td32{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 70px;vertical-align: bottom;}
.td33{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 69px;vertical-align: bottom;}
.td34{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 28px;vertical-align: bottom;}
.td35{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 16px;vertical-align: bottom;}
.td36{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 259px;vertical-align: bottom;}
.td37{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 35px;vertical-align: bottom;}
.td38{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 35px;vertical-align: bottom;}
.td39{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 69px;vertical-align: bottom;}
.td40{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 22px;vertical-align: bottom;}
.td41{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 28px;vertical-align: bottom;}
.td42{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 41px;vertical-align: bottom;}
.td43{padding: 0px;margin: 0px;width: 35px;vertical-align: bottom;}
.td44{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 35px;vertical-align: bottom;}
.td45{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 22px;vertical-align: bottom;}
.td46{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 13px;vertical-align: bottom;}
.td47{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 41px;vertical-align: bottom;}
.td48{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 218px;vertical-align: bottom;}
.td49{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 25px;vertical-align: bottom;}
.td50{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 10px;vertical-align: bottom;}
.td51{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 42px;vertical-align: bottom;}
.td52{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 78px;vertical-align: bottom;}
.td53{padding: 0px;margin: 0px;width: 299px;vertical-align: bottom;}
.td54{padding: 0px;margin: 0px;width: 10px;vertical-align: bottom;}
.td55{padding: 0px;margin: 0px;width: 42px;vertical-align: bottom;}
.td56{padding: 0px;margin: 0px;width: 14px;vertical-align: bottom;}
.td57{padding: 0px;margin: 0px;width: 43px;vertical-align: bottom;}
.td58{padding: 0px;margin: 0px;width: 80px;vertical-align: bottom;}
.td59{padding: 0px;margin: 0px;width: 401px;vertical-align: bottom;}
.td60{padding: 0px;margin: 0px;width: 78px;vertical-align: bottom;}
.td61{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 14px;vertical-align: bottom;}
.td62{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 244px;vertical-align: bottom;}
.td63{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 88px;vertical-align: bottom;}
.td64{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 80px;vertical-align: bottom;}
.td65{padding: 0px;margin: 0px;width: 41px;vertical-align: bottom;}
.td66{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 243px;vertical-align: bottom;}
.td67{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 77px;vertical-align: bottom;}
.td68{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 115px;vertical-align: bottom;}
.td69{padding: 0px;margin: 0px;width: 219px;vertical-align: bottom;}
.td70{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 24px;vertical-align: bottom;}
.td71{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 87px;vertical-align: bottom;}
.td72{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 55px;vertical-align: bottom;}
.td73{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 219px;vertical-align: bottom;}
.td74{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 24px;vertical-align: bottom;}
.td75{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 77px;vertical-align: bottom;}
.td76{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 41px;vertical-align: bottom;}
.td77{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 87px;vertical-align: bottom;}
.td78{padding: 0px;margin: 0px;width: 60px;vertical-align: bottom;}
.td79{border-top: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 3px;vertical-align: bottom;}
.td80{border-top: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 14px;vertical-align: bottom;}
.td81{border-top: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 41px;vertical-align: bottom;}
.td82{border-right: #000000 1px solid;border-top: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 243px;vertical-align: bottom;}
.td83{border-right: #000000 1px solid;border-top: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 87px;vertical-align: bottom;}
.td84{border-right: #000000 1px solid;border-top: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 27px;vertical-align: bottom;}
.td85{border-top: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 10px;vertical-align: bottom;}
.td86{border-top: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 78px;vertical-align: bottom;}
.td87{padding: 0px;margin: 0px;width: 244px;vertical-align: bottom;}
.td88{padding: 0px;margin: 0px;width: 541px;vertical-align: bottom;}
.td89{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 299px;vertical-align: bottom;}
.td90{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 42px;vertical-align: bottom;}
.td91{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 43px;vertical-align: bottom;}
.td92{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 9px;vertical-align: bottom;}
.td93{padding: 0px;margin: 0px;width: 25px;vertical-align: bottom;}
.td94{padding: 0px;margin: 0px;width: 135px;vertical-align: bottom;}

.tr0{height: 22px;}
.tr1{height: 17px;}
.tr2{height: 16px;}
.tr3{height: 13px;}
.tr4{height: 12px;}
.tr5{height: 6px;}
.tr6{height: 5px;}
.tr7{height: 7px;}
.tr8{height: 14px;}
.tr9{height: 18px;}
.tr10{height: 51px;}
.tr11{height: 19px;}
.tr12{height: 25px;}
.tr13{height: 10px;}
.tr14{height: 9px;}
.tr15{height: 26px;}
.tr16{height: 86px;}
.tr17{height: 21px;}
.tr18{height: 20px;}
.tr19{height: 3px;}
.tr20{height: 15px;}
.tr21{height: 4px;}
.tr22{height: 24px;}
.tr23{height: 69px;}
.tr24{height: 36px;}
.tr25{height: 35px;}
.tr26{height: 40px;}

.t0{width: 626px;margin-top: 13px;font: 11px 'Helvetica';}
.t1{width: 626px;font: 12px 'Helvetica';}

</style>
</head>
<body>
<div id="page_1">
<div id="p1dimg1">
<img src="data:image/jpg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCANTAnEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD0Pwn4T06fR7h3udZBGp36fJrV4gwt3Mo4WUDOByepOSckk1uf8Ibpf/P1rn/g9vf/AI9R4N/5Adz/ANhXUv8A0tmroKAOf/4Q3S/+frXP/B7e/wDx6j/hDdL/AOfrXP8Awe3v/wAeroKKAOf/AOEN0v8A5+tc/wDB7e//AB6j/hDdL/5+tc/8Ht7/APHq6CigDn/+EN0v/n61z/we3v8A8eo/4Q3S/wDn61z/AMHt7/8AHq6CigDn/wDhDdL/AOfrXP8Awe3v/wAeo/4Q3S/+frXP/B7e/wDx6ugooA5//hDdL/5+tc/8Ht7/APHqP+EN0v8A5+tc/wDB7e//AB6ugooA5/8A4Q3S/wDn61z/AMHt7/8AHqP+EN0v/n61z/we3v8A8eroKKAOf/4Q3S/+frXP/B7e/wDx6j/hDdL/AOfrXP8Awe3v/wAeroKKAOf/AOEN0v8A5+tc/wDB7e//AB6j/hDdL/5+tc/8Ht7/APHq6CigDn/+EN0v/n61z/we3v8A8eo/4Q3S/wDn61z/AMHt7/8AHq6CigDn/wDhDdL/AOfrXP8Awe3v/wAeo/4Q3S/+frXP/B7e/wDx6ugooA5//hDdL/5+tc/8Ht7/APHqP+EN0v8A5+tc/wDB7e//AB6ugooA5/8A4Q3S/wDn61z/AMHt7/8AHqP+EN0v/n61z/we3v8A8eroKKAOf/4Q3S/+frXP/B7e/wDx6j/hDdL/AOfrXP8Awe3v/wAeroKKAOf/AOEN0v8A5+tc/wDB7e//AB6j/hDdL/5+tc/8Ht7/APHq6CigDn/+EN0v/n61z/we3v8A8eo/4Q3S/wDn61z/AMHt7/8AHq6CigDn/wDhDdL/AOfrXP8Awe3v/wAeo/4Q3S/+frXP/B7e/wDx6ugooA5//hDdL/5+tc/8Ht7/APHqP+EN0v8A5+tc/wDB7e//AB6ugooA5/8A4Q3S/wDn61z/AMHt7/8AHqP+EN0v/n61z/we3v8A8eroKKAOf/4Q3S/+frXP/B7e/wDx6j/hDdL/AOfrXP8Awe3v/wAeroKKAOf/AOEN0v8A5+tc/wDB7e//AB6j/hDdL/5+tc/8Ht7/APHq6CigDn/+EN0v/n61z/we3v8A8eo/4Q3S/wDn61z/AMHt7/8AHq6CigDn/wDhDdL/AOfrXP8Awe3v/wAeo/4Q3S/+frXP/B7e/wDx6ugooA5//hDdL/5+tc/8Ht7/APHqP+EN0v8A5+tc/wDB7e//AB6ugooA5/8A4Q3S/wDn61z/AMHt7/8AHqP+EN0v/n61z/we3v8A8eroKKAOf/4Q3S/+frXP/B7e/wDx6j/hDdL/AOfrXP8Awe3v/wAeroKKAOf/AOEN0v8A5+tc/wDB7e//AB6j/hDdL/5+tc/8Ht7/APHq6CigDn/+EN0v/n61z/we3v8A8eo/4Q3S/wDn61z/AMHt7/8AHq6CigDn/wDhDdL/AOfrXP8Awe3v/wAeo/4Q3S/+frXP/B7e/wDx6ugooA5//hDdL/5+tc/8Ht7/APHqP+EN0v8A5+tc/wDB7e//AB6ugooA5/8A4Q3S/wDn61z/AMHt7/8AHqP+EN0v/n61z/we3v8A8eroKKAOf/4Q3S/+frXP/B7e/wDx6j/hDdL/AOfrXP8Awe3v/wAeroKKAOf/AOEN0v8A5+tc/wDB7e//AB6j/hDdL/5+tc/8Ht7/APHq6CigDn/+EN0v/n61z/we3v8A8eo/4Q3S/wDn61z/AMHt7/8AHq6CigDn/wDhDdL/AOfrXP8Awe3v/wAeo/4Q3S/+frXP/B7e/wDx6ugooA5//hDdL/5+tc/8Ht7/APHqP+EN0v8A5+tc/wDB7e//AB6ugooA5/8A4Q3S/wDn61z/AMHt7/8AHqP+EN0v/n61z/we3v8A8eroKKAOf/4Q3S/+frXP/B7e/wDx6j/hDdL/AOfrXP8Awe3v/wAeroKKAOf/AOEN0v8A5+tc/wDB7e//AB6j/hDdL/5+tc/8Ht7/APHq6CigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf8AsK6l/wCls1dBXP8Ag3/kB3P/AGFdS/8AS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/AAb/AMgO5/7Cupf+ls1dBXP+Df8AkB3P/YV1L/0tmroKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+AKKKKAPt/wb/wAgO5/7Cupf+ls1dBXP+Df+QHc/9hXUv/S2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA+3/Bv/IDuf+wrqX/pbNXQVz/g3/kB3P8A2FdS/wDS2augoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD4AooooA7iz+L/jvT4Ghtdd8uNpZJiPskBy8jtI55TuzMfbPHFWP+F2/EP8A6GH/AMkrf/43RRQAf8Lt+If/AEMP/klb/wDxuj/hdvxD/wChh/8AJK3/APjdFFAB/wALt+If/Qw/+SVv/wDG6P8AhdvxD/6GH/ySt/8A43RRQAf8Lt+If/Qw/wDklb//ABuj/hdvxD/6GH/ySt//AI3RRQAf8Lt+If8A0MP/AJJW/wD8bo/4Xb8Q/wDoYf8AySt//jdFFAB/wu34h/8AQw/+SVv/APG6P+F2/EP/AKGH/wAkrf8A+N0UUAH/AAu34h/9DD/5JW//AMbo/wCF2/EP/oYf/JK3/wDjdFFAB/wu34h/9DD/AOSVv/8AG6P+F2/EP/oYf/JK3/8AjdFFAB/wu34h/wDQw/8Aklb/APxuj/hdvxD/AOhh/wDJK3/+N0UUAH/C7fiH/wBDD/5JW/8A8bo/4Xb8Q/8AoYf/ACSt/wD43RRQAf8AC7fiH/0MP/klb/8Axuj/AIXb8Q/+hh/8krf/AON0UUAH/C7fiH/0MP8A5JW//wAbo/4Xb8Q/+hh/8krf/wCN0UUAH/C7fiH/ANDD/wCSVv8A/G6P+F2/EP8A6GH/AMkrf/43RRQAf8Lt+If/AEMP/klb/wDxuj/hdvxD/wChh/8AJK3/APjdFFAB/wALt+If/Qw/+SVv/wDG6P8AhdvxD/6GH/ySt/8A43RRQAf8Lt+If/Qw/wDklb//ABuj/hdvxD/6GH/ySt//AI3RRQAf8Lt+If8A0MP/AJJW/wD8bo/4Xb8Q/wDoYf8AySt//jdFFAB/wu34h/8AQw/+SVv/APG6P+F2/EP/AKGH/wAkrf8A+N0UUAH/AAu34h/9DD/5JW//AMbo/wCF2/EP/oYf/JK3/wDjdFFAB/wu34h/9DD/AOSVv/8AG6P+F2/EP/oYf/JK3/8AjdFFAB/wu34h/wDQw/8Aklb/APxuj/hdvxD/AOhh/wDJK3/+N0UUAH/C7fiH/wBDD/5JW/8A8bo/4Xb8Q/8AoYf/ACSt/wD43RRQAf8AC7fiH/0MP/klb/8Axuj/AIXb8Q/+hh/8krf/AON0UUAH/C7fiH/0MP8A5JW//wAbo/4Xb8Q/+hh/8krf/wCN0UUAH/C7fiH/ANDD/wCSVv8A/G6P+F2/EP8A6GH/AMkrf/43RRQAf8Lt+If/AEMP/klb/wDxuj/hdvxD/wChh/8AJK3/APjdFFAB/wALt+If/Qw/+SVv/wDG6P8AhdvxD/6GH/ySt/8A43RRQAf8Lt+If/Qw/wDklb//ABuj/hdvxD/6GH/ySt//AI3RRQAf8Lt+If8A0MP/AJJW/wD8bo/4Xb8Q/wDoYf8AySt//jdFFAB/wu34h/8AQw/+SVv/APG6P+F2/EP/AKGH/wAkrf8A+N0UUAH/AAu34h/9DD/5JW//AMbo/wCF2/EP/oYf/JK3/wDjdFFAB/wu34h/9DD/AOSVv/8AG6P+F2/EP/oYf/JK3/8AjdFFAB/wu34h/wDQw/8Aklb/APxuj/hdvxD/AOhh/wDJK3/+N0UUAH/C7fiH/wBDD/5JW/8A8bo/4Xb8Q/8AoYf/ACSt/wD43RRQAf8AC7fiH/0MP/klb/8Axuj/AIXb8Q/+hh/8krf/AON0UUAH/C7fiH/0MP8A5JW//wAbo/4Xb8Q/+hh/8krf/wCN0UUAH/C7fiH/ANDD/wCSVv8A/G6P+F2/EP8A6GH/AMkrf/43RRQAf8Lt+If/AEMP/klb/wDxuj/hdvxD/wChh/8AJK3/APjdFFAB/wALt+If/Qw/+SVv/wDG6P8AhdvxD/6GH/ySt/8A43RRQB5/RRRQB//Z" alt=""></div>
<div id="id_1">
<p class="p0 ft0">Tax Invoice</p>
<?php $getbill = Session::get('sendbill');?>
<table cellpadding="0" cellspacing="0" class="t0">
<tbody><tr>
	<?php $user =  DB::table('branch_info')->where('id',$getbill[0]->branch_id)->first(); ?>
	<td class="tr0 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr0 td1"><p class="p2 ft2">{{$user->shopName}}</p></td>
	<td class="tr0 td2"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr0 td3"><p class="p2 ft3">Invoice No</p></td>
	<td class="tr0 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr0 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr0 td6"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="4" class="tr0 td7"><p class="p3 ft3">DATE</p></td>
	<td class="tr0 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr0 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr0 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr0 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr1 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr1 td1"><p class="p2 ft3">{{$user->add1}}</p></td>
	<td class="tr1 td2"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="3" class="tr2 td11"><p class="p2 ft4">IN{{$getbill[0]->invoice_no}}</p></td>
	<td class="tr2 td12"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td6"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="4" class="tr2 td13"><p class="p3 ft4"><nobr>{{$getbill[0]->date}}</nobr></p></td>
	<td class="tr2 td14"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr3 td0"><p class="p1 ft5">&nbsp;</p></td>
	<td colspan="2" class="tr3 td1"><p class="p2 ft6"></p>{{$user->add2}}</td>
	<td class="tr3 td2"><p class="p1 ft5">&nbsp;</p></td>
	<td colspan="2" class="tr3 td3"><p class="p2 ft6">Supplier’s Ref.</p></td>
	<td class="tr3 td4"><p class="p1 ft5">&nbsp;</p>{{$getbill[0]->sup_ref}}</td>
	<td class="tr3 td5"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td6"><p class="p1 ft5">&nbsp;</p></td>
	<td colspan="5" class="tr3 td15"><p class="p3 ft6">Other Reference(s)</p></td>
	<td class="tr3 td9"><p class="p1 ft5">&nbsp;</p>{{$getbill[0]->other_ref}}</td>
	<td class="tr3 td10"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td0"><p class="p1 ft5">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr4 td0"><p class="p1 ft7">&nbsp;</p></td>
	<td colspan="2" class="tr4 td1"><p class="p2 ft8">{{$user->city}},{{$user->state}}-{{$user->pin}}</p></td>
	<td class="tr4 td2"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td16"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td8"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td4"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td5"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td6"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td17"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td4"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td0"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td18"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td8"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td9"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td10"><p class="p1 ft7">&nbsp;</p></td>
	<td class="tr4 td0"><p class="p1 ft7">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr5 td0"><p class="p1 ft9">&nbsp;</p></td>
	<td colspan="2" rowspan="2" class="tr3 td1"><p class="p2 ft6">GSTIN/UIN: {{$user->gst}}</p></td>
	<td class="tr5 td2"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr6 td19"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td14"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td20"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td12"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr5 td6"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr6 td21"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td20"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td22"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td23"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td14"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr5 td9"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td10"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td0"><p class="p1 ft9">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr7 td0"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td2"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td16"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td8"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td4"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td5"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td10"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td17"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td4"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td0"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td18"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td8"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td9"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td10"><p class="p1 ft11">&nbsp;</p></td>
	<td class="tr7 td0"><p class="p1 ft11">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr8 td1"><p class="p2 ft3">Contact : {{$user->mob}}</p></td>
	<td class="tr8 td2"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td17"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr3 td0"><p class="p1 ft5">&nbsp;</p></td>
	<td colspan="2" class="tr3 td1"><p class="p2 ft6"><nobr>E-Mail :</nobr> {{$user->email}}</p></td>
	<td class="tr3 td2"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td16"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td8"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td4"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td5"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td10"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td17"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td4"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td0"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td18"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td8"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td9"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td10"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td0"><p class="p1 ft5">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr5 td0"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr6 td24"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td25"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr6 td26"><p class="p1 ft10">&nbsp;</p></td>
	<td class="tr5 td16"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td8"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td4"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td5"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td10"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td17"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td4"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td0"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td18"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td8"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td9"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td10"><p class="p1 ft9">&nbsp;</p></td>
	<td class="tr5 td0"><p class="p1 ft9">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr1 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr1 td1"><p class="p2 ft12">Buyer</p></td>
	<td class="tr1 td2"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td17"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
	<?php $owner =  DB::table('shop_info')->where('id',$getbill[0]->shop_id)->first(); ?>
	<td colspan="2" class="tr9 td1"><p class="p2 ft2">{{$owner->shopName}}</p></td>
	<td class="tr9 td2"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td17"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr8 td1"><p class="p2 ft3">GSTIN/UIN: {{$owner->gst}}</p></td>
	<td class="tr8 td2"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td17"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr8 td1"><p class="p2 ft3">{{$owner->add1}}</p></td>
	<td class="tr8 td2"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td17"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td8"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr8 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr3 td0"><p class="p1 ft5">&nbsp;</p></td>
	<td colspan="2" class="tr3 td1"><p class="p2 ft6">{{$owner->city}},{{$owner->state}}-{{$owner->pin}}</p></td>
	<td class="tr3 td2"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td16"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td8"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td4"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td5"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td10"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td17"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td4"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td0"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td18"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td8"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td9"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td10"><p class="p1 ft5">&nbsp;</p></td>
	<td class="tr3 td0"><p class="p1 ft5">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr10 td22"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td24"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td25"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td26"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td19"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td14"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="4" class="tr10 td27"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td20"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td22"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td23"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td14"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td28"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td29"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr10 td22"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td30"><p class="p2 ft13">Sl</p></td>
	<td class="tr9 td31"><p class="p4 ft12">Description of Goods</p></td>
	<td colspan="2" class="tr9 td32"><p class="p5 ft12">HSN/SAC</p></td>
	<td class="tr9 td33"><p class="p6 ft12">Quantity</p></td>
	<td colspan="4" class="tr9 td32"><p class="p7 ft12">Rate</p></td>
	<td class="tr9 td34"><p class="p8 ft12">per</p></td>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td8"><p class="p9 ft3">Amount</p></td>
	<td class="tr9 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr11 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td35"><p class="p2 ft14">No.</p></td>
	<td class="tr9 td36"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td37"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td38"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td39"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td20"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td12"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td29"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td40"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td41"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td22"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td23"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td14"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td28"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td29"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr11 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<?php $items = DB::table('item_info')->where('bill_id',$getbill[0]->bill_id)->get();  ?>
<?php $counter =1; $total_net =0; $total_gst = 0; $total_quantity = 0;?>
@foreach($items as $item)
<tr>
	<td class="tr12 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr12 td30"><p class="p2 ft13">{{$counter}}</p></td>
	<td class="tr12 td31"><p class="p3 ft2">{{$item->item}}</p></td>
	<td colspan="2" class="tr12 td32"><p class="p9 ft3">{{$item->hsn_sac}}</p></td>
	<td class="tr12 td33"><p class="p10 ft2">{{$item->quantity}}</p></td>
	<td class="tr12 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="3" class="tr12 td42"><p class="p11 ft3">{{$item->rate}}</p></td>
	<td class="tr12 td34"><p class="p12 ft12">nos</p></td>
	<td class="tr12 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr12 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr12 td8"><p class="p13 ft2">{{$item->total_net}}</p></td>
	<td class="tr12 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr12 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr12 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<?php $total_net = $total_net +  $item->total_net; ?>
<?php $total_gst =  $total_gst+ $item->total_gst; ?>
<?php $total_quantity =  $total_quantity+ $item->quantity; ?>
<?php $counter++; ?>
@endforeach
<tr>
	<td class="tr13 td0"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td30"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td31"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td43"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td44"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td33"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td4"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td5"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td10"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td45"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td34"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td0"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr14 td23"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td14"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td28"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr13 td10"><p class="p1 ft16">&nbsp;</p></td>
	<td class="tr13 td0"><p class="p1 ft16">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td30"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td31"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td43"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td44"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td33"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td45"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td34"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td8"><p class="p15 ft13">{{$total_net}}</p></td>
	<td class="tr9 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr15 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td30"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td31"><p class="p16 ft18">Output IGST @ {{$getbill[0]->sgst + $getbill[0]->cgst}}%</p></td>
	<td class="tr15 td43"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td44"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td33"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="3" class="tr15 td42"><p class="p17 ft19">{{$getbill[0]->sgst + $getbill[0]->cgst}}</p></td>
	<td class="tr15 td34"><p class="p18 ft19">%</p></td>
	<td class="tr15 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td8"><p class="p13 ft2">{{$total_gst}}</p></td>
	<td class="tr15 td9"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr15 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr16 td22"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td35"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td36"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td37"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td38"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td39"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td20"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td12"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td29"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td40"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td41"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td22"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td23"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td14"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td28"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td29"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr16 td22"><p class="p1 ft1">&nbsp;</p></td>
</tr>
</tbody></table>
<table cellpadding="0" cellspacing="0" class="t1">
<tbody><tr>
	<td class="tr17 td22"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td29"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td46"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td47"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td48"><p class="p19 ft12">Total</p></td>
	<td class="tr17 td49"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td50"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td38"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="3" class="tr17 td39"><p class="p10 ft2">{{$total_quantity}} nos</p></td>
	<td class="tr17 td23"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td51"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td41"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td12"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td50"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr17 td52"><p class="p20 ft0">{{$total_net + $total_gst}}</p></td>
	<td class="tr17 td22"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr2 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="4" class="tr2 td53"><p class="p1 ft12">Amount Chargeable (in words)</p></td>
	<td class="tr2 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td55"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td57"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr2 td58"><p class="p21 ft15">E. &amp; O.E</p></td>
</tr>
<tr>
	<td class="tr18 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr18 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="8" class="tr18 td59"><p class="p1 ft2">Indian Rupees {{getIndianCurrency($total_net + $total_gst)}} Only</p></td>
	<td class="tr18 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr18 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr18 td57"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr18 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr18 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr18 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr18 td60"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr18 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr19 td22"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td29"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td61"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td47"><p class="p1 ft20">&nbsp;</p></td>
	<td colspan="2" class="tr19 td62"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td50"><p class="p1 ft20">&nbsp;</p></td>
	<td colspan="2" class="tr19 td52"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td61"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td61"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td23"><p class="p1 ft20">&nbsp;</p></td>
	<td colspan="3" class="tr19 td63"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td50"><p class="p1 ft20">&nbsp;</p></td>
	<td colspan="2" class="tr19 td64"><p class="p1 ft20">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr11 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr11 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr11 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr11 td65"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr11 td66"><p class="p22 ft12">HSN/SAC</p></td>
	<td class="tr11 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr11 td67"><p class="p7 ft12">Taxable</p></td>
	<td class="tr9 td61"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td61"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="4" class="tr9 td68"><p class="p23 ft3">Integrated Tax</p></td>
	<td class="tr11 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr11 td58"><p class="p24 ft12">Total</p></td>
</tr>
<tr>
	<td class="tr20 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td65"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td69"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td70"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr20 td67"><p class="p25 ft12">Value</p></td>
	<td class="tr20 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr20 td42"><p class="p26 ft3">Rate</p></td>
	<td colspan="3" class="tr20 td71"><p class="p27 ft12">Amount</p></td>
	<td class="tr20 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr20 td58"><p class="p1 ft12">Tax Amount</p></td>
</tr>
<tr>
	<td class="tr21 td0"><p class="p1 ft21">&nbsp;</p></td>
	<td class="tr19 td29"><p class="p1 ft20">&nbsp;</p></td>
	<td colspan="2" class="tr19 td72"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td73"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td74"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td50"><p class="p1 ft20">&nbsp;</p></td>
	<td colspan="2" class="tr19 td75"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td61"><p class="p1 ft20">&nbsp;</p></td>
	<td colspan="2" class="tr19 td76"><p class="p1 ft20">&nbsp;</p></td>
	<td colspan="3" class="tr19 td77"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td50"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr19 td52"><p class="p1 ft20">&nbsp;</p></td>
	<td class="tr21 td0"><p class="p1 ft21">&nbsp;</p></td>
</tr>
<?php $sitems = DB::table('item_info')->where('bill_id',$getbill[0]->bill_id)->get();  ?>
@foreach ($sitems as $sitem)
<tr>
	<td colspan="4" class="tr20 td78"><p class="p8 ft12">{{$sitem->hsn_sac}}</p></td>
	<td class="tr20 td69"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td70"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="3" class="tr20 td71"><p class="p28 ft12">{{$sitem->total_net}}</p></td>
	<td class="tr20 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr20 td42"><p class="p28 ft12">{{$sitem->sgst + $sitem->cgst}}%</p></td>
	<td colspan="3" class="tr20 td71"><p class="p13 ft12">{{$sitem->total_gst}}</p></td>
	<td class="tr20 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td60"><p class="p11 ft12">{{$sitem->total_gst}}</p></td>
	<td class="tr20 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
@endforeach
<tr>
	<td class="tr11 td22"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td79"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td80"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td81"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr9 td82"><p class="p29 ft4">Total</p></td>
	<td colspan="3" class="tr9 td83"><p class="p13 ft4">{{$total_net}}</p></td>
	<td class="tr9 td80"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td80"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td84"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="3" class="tr9 td83"><p class="p13 ft4">{{$total_gst}}</p></td>
	<td class="tr9 td85"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr9 td86"><p class="p11 ft4">{{$total_gst}}</p></td>
	<td class="tr11 td22"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr22 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr22 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="8" class="tr22 td59"><p class="p1 ft4"><span class="ft3">Tax Amount (in words) : </span>{{getIndianCurrency($total_gst)}}</p></td>
	<td class="tr22 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr22 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr22 td57"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr22 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr22 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr22 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr22 td60"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr22 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr23 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="4" class="tr23 td53"><p class="p1 ft15">Remarks:</p></td>
	<td class="tr23 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td55"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td57"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td60"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr23 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr20 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="4" class="tr20 td53"><p class="p1 ft12">Paid - MOJO7828005A90802831</p></td>
	<td class="tr20 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td55"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td57"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td60"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr20 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr24 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr25 td72"><p class="p1 ft3">Declaration</p></td>
	<td colspan="2" class="tr24 td87"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td55"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td57"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td60"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr24 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr2 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="14" class="tr2 td88"><p class="p1 ft3">We declare that this invoice shows the actual price of the goods described and that all particulars are true and</p></td>
	<td class="tr2 td60"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr2 td0"><p class="p1 ft1">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr8 td0"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td10"><p class="p1 ft22">&nbsp;</p></td>
	<td colspan="4" class="tr8 td53"><p class="p1 ft23">correct.</p></td>
	<td class="tr8 td54"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td16"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td55"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td56"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td56"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td18"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td57"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td4"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td5"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td54"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td60"><p class="p1 ft22">&nbsp;</p></td>
	<td class="tr8 td0"><p class="p1 ft22">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr14 td22"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td29"><p class="p1 ft17">&nbsp;</p></td>
	<td colspan="4" class="tr14 td89"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td50"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td19"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td90"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td61"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td61"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td23"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td91"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td20"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td12"><p class="p1 ft17">&nbsp;</p></td>
	<td class="tr14 td50"><p class="p1 ft17">&nbsp;</p></td>
	<td colspan="2" class="tr14 td64"><p class="p1 ft17">&nbsp;</p></td>
</tr>
<tr>
	<td class="tr1 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="4" class="tr1 td53"><p class="p1 ft12">Customer’s Seal and Signature</p></td>
	<td class="tr1 td92"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td55"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td57"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td4"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td5"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr1 td54"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="2" class="tr1 td58"><p class="p30 ft4" style="margin-left:-3em;">for {{$user->shopName}}</p></td>
</tr>
<tr>
	<td class="tr26 td0"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td10"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td65"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td69"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td93"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td92"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td16"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td55"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td56"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td18"><p class="p1 ft1">&nbsp;</p></td>
	<td class="tr26 td57"><p class="p1 ft1">&nbsp;</p></td>
	<td colspan="5" class="tr26 td94"><p class="p31 ft3">Authorised Signatory</p></td>
</tr>
</tbody></table>
</div>
<div id="id_2">
<p class="p32 ft12">This is a Computer Generated Invoice</p>
</div>
</div>
<div style="padding: 50px 0px 15px 20px; font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #c8c8c8;">
	<p><a href="http://pdfonline.com/pdf-to-word-converter/" style="color: #c8c8c8; text-decoration: none;">PDF to Word</a> P2WConvertedByBCLTechnologies</p>
</div>


</body></html>
